import './App.css';
import axios from "axios"
import React ,{useEffect,useState} from 'react';
function App() {
  const [data,setData] = useState([]);
  
const getData =  () =>{
    fetch("https://hiring.bajajfinservhealth.in/api/renderMe",{mode:'no-cors'}).then(
      response=>{
        return response.json();
      }
    ).then(temp=>{
      console.log(temp);
      setData(temp)
    })
  }
  useEffect(()=>{
    getData()
  },[]);
  return (
    <div className="App">
      <ul>
        {
          data.map(
            d =>(
              <div>
              <li key={d.id}>Login : {d.login}</li>
              <li key={d.id}>Avatar : {d.avatar_id}</li>
              <li key={d.id}>Html url : {d.url.html_url}</li>
              <li key={d.id}>type : {d.type}</li>
              </div>
            )
          )
        }
      </ul>
    </div>
  );
}

export default App;
